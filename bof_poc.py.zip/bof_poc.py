#python version 3.9

import os, subprocess

data, temp = os.pipe()

os.write(temp, b"9999999999")  #a value greater than the buffer size
os.close(temp)

subprocess.run(["g++", "question.cpp", "-o", "output"]) #using subprocess to send the value to stdin
output = subprocess.run("./output", stdin = data, capture_output = True, shell = True) #storing the output

print(output)

